# Notepad.java
A Notepad created using core-java
